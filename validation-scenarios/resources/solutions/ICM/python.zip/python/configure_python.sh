#!/bin/bash

# UDANext Supplied Values
AUTO_FILES_PATH=@auto.files.path@
AUTO_DUMP_PATH=@auto.dump.path@
INGRESS_HOST=@k8s.ingress.host@
NAMESPACE=@k8s.namespace@


mkdir -p $AUTO_DUMP_PATH/charts/site-config/sas-pyconfig

cp -R $AUTO_DUMP_PATH/charts/sas-bases/examples/sas-pyconfig/* $AUTO_DUMP_PATH/charts/site-config/sas-pyconfig

# change /data/global.enabled to true
sed -i.bak '/^ *path: \/data\/global.enabled/,/^ *-*/s/value: \"false\"/value: \"true\"/' $AUTO_DUMP_PATH/charts/site-config/sas-pyconfig/change-configuration.yaml
# change /data/global.python_enabled to true
sed -i '/^ *path: \/data\/global.python_enabled/,/^ *-*/s/value: \"false\"/value: \"true\"/' $AUTO_DUMP_PATH/charts/site-config/sas-pyconfig/change-configuration.yaml
# change the pgp key source to be compatible with python 3.8
# sed -i 's/pablogsal/ambv/g' $AUTO_DUMP_PATH/charts/site-config/sas-pyconfig/change-configuration.yaml
# change default python version to be installed to 3.8.18
# sed -i 's/3.11.10/3.8.18/g' $AUTO_DUMP_PATH/charts/site-config/sas-pyconfig/change-configuration.yaml
# add saspy, pandas, and openpyxl in required modules
sed -i 's/Prophet.*/saspy pandas openpyxl defusedxml pydantic-core numpy"/g' $AUTO_DUMP_PATH/charts/site-config/sas-pyconfig/change-configuration.yaml


# now for change-limits.yaml
# the resources are too high on our openstack deployments - the job can't get scheduled
sed -i.bak 's/4000m/26m/' $AUTO_DUMP_PATH/charts/site-config/sas-pyconfig/change-limits.yaml
sed -i 's/3000Mi/26Mi/' $AUTO_DUMP_PATH/charts/site-config/sas-pyconfig/change-limits.yaml

# now sas-open-source-config
mkdir -p $AUTO_DUMP_PATH/charts/site-config/sas-open-source-config

cp -R $AUTO_FILES_PATH/preKustomize/python/sas-open-source-config/* $AUTO_DUMP_PATH/charts/site-config/sas-open-source-config
# cp -R $AUTO_DUMP_PATH/charts/sas-bases/examples/sas-open-source-config/* $AUTO_DUMP_PATH/charts/site-config/sas-open-source-config

sed -i.bak 's/{{ PYTHON-EXE-DIR }}/default_py\/bin/' $AUTO_DUMP_PATH/charts/site-config/sas-open-source-config/python/kustomization.yaml
sed -i 's/{{ PYTHON-EXECUTABLE }}/python3/' $AUTO_DUMP_PATH/charts/site-config/sas-open-source-config/python/kustomization.yaml
sed -i 's/\/python/\/opt\/sas\/viya\/home\/sas-pyconfig/' $AUTO_DUMP_PATH/charts/site-config/sas-open-source-config/python/kustomization.yaml
sed -i 's/{{ SAS-EXT-LLP-PYTHON-PATH }}/\/opt\/sas\/viya\/home\/sas-pyconfig\/default_py\/lib\/python3.8\/site-packages/' $AUTO_DUMP_PATH/charts/site-config/sas-open-source-config/python/kustomization.yaml

# now for python-transformer
sed -i.bak 's/{{ VOLUME-ATTRIBUTES }}/persistentVolumeClaim: {claimName: sas-pyconfig, readOnly: true}/' $AUTO_DUMP_PATH/charts/site-config/sas-open-source-config/python/python-transformer.yaml
sed -i 's/mountPath: \/python/mountPath: \/opt\/sas\/viya\/home\/sas-pyconfig/' $AUTO_DUMP_PATH/charts/site-config/sas-open-source-config/python/python-transformer.yaml

# now for sas-airflow's python-transformer
# mkdir -p $AUTO_DUMP_PATH/charts/site-config/sas-airflow/python
# cp -R $AUTO_DUMP_PATH/charts/sas-bases/examples/sas-airflow/python/* $AUTO_DUMP_PATH/charts/site-config/sas-airflow/python
# sed -i.bak 's/{{ VOLUME-ATTRIBUTES }}/persistentVolumeClaim: {claimName: sas-pyconfig, readOnly: true}/' $AUTO_DUMP_PATH/charts/site-config/sas-airflow/python/python-transformer.yaml
# sed -i 's/mountPath: \/python/mountPath: \/opt\/sas\/viya\/home\/sas-pyconfig/' $AUTO_DUMP_PATH/charts/site-config/sas-airflow/python/python-transformer.yaml

# for fermi's python-transformer
mkdir -p $AUTO_DUMP_PATH/charts/site-config/sas-fermi/python-config
#cp -R $AUTO_DUMP_PATH/charts/sas-bases/examples/python-config/* $AUTO_DUMP_PATH/charts/site-config/sas-fermi/python-config
cp -R $AUTO_DUMP_PATH/charts/sas-bases/examples/sas-fermi/python-config/* $AUTO_DUMP_PATH/charts/site-config/sas-fermi/python-config
sed -i.bak 's/{{ VOLUME-ATTRIBUTES }}/persistentVolumeClaim: {claimName: sas-pyconfig, readOnly: true}/' $AUTO_DUMP_PATH/charts/site-config/sas-fermi/python-config/python-transformer.yaml
sed -i 's/mountPath: \/python/mountPath: \/opt\/sas\/viya\/home\/sas-pyconfig/' $AUTO_DUMP_PATH/charts/site-config/sas-fermi/python-config/python-transformer.yaml

# lockdown
mkdir -p $AUTO_DUMP_PATH/charts/site-config/sas-programming-environment/lockdown

cp -R $AUTO_DUMP_PATH/charts/sas-bases/examples/sas-programming-environment/lockdown/* $AUTO_DUMP_PATH/charts/site-config/sas-programming-environment/lockdown
sed -i.bak 's/{{ ACCESS-METHOD-LIST }}/python python_embed/' $AUTO_DUMP_PATH/charts/site-config/sas-programming-environment/lockdown/enable-lockdown-access-methods.yaml



# now for the main kustomization.yaml
sed -i.before.python.bak '/^transformers:.*/a \ \ - site-config/sas-pyconfig/change-limits.yaml' $AUTO_DUMP_PATH/charts/kustomization.yaml
sed -i '/^transformers:.*/a \ \ - site-config/sas-programming-environment/lockdown/enable-lockdown-access-methods.yaml' $AUTO_DUMP_PATH/charts/kustomization.yaml
sed -i '/^transformers:.*/a \ \ - site-config/sas-pyconfig/change-configuration.yaml' $AUTO_DUMP_PATH/charts/kustomization.yaml
# sed -i '/^transformers:.*/a \ \ - site-config/sas-airflow/python/python-transformer.yaml' $AUTO_DUMP_PATH/charts/kustomization.yaml
sed -i '/^transformers:.*/a \ \ - site-config/sas-fermi/python-config/python-transformer.yaml' $AUTO_DUMP_PATH/charts/kustomization.yaml
sed -i '/^transformers:.*/a \ \ - site-config/sas-open-source-config/python/python-transformer.yaml' $AUTO_DUMP_PATH/charts/kustomization.yaml
sed -i '/^resources:.*/a \ \ - site-config/sas-open-source-config/python' $AUTO_DUMP_PATH/charts/kustomization.yaml
